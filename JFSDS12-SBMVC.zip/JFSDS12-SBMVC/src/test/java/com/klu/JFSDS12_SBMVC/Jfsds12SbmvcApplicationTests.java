package com.klu.JFSDS12_SBMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jfsds12SbmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
