package com.klu.JFSDS12_SBMVC;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/SpringMVC")
public class ClientController {

	
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome";
	}
	@GetMapping("/test")
	public String test() {
		return "test";
	}
	@GetMapping("/showInfo")
	public String showInfo(@RequestParam("id") int id, @RequestParam("name") String name, Model model) {
		model.addAttribute("id", id);
		model.addAttribute("name",name);
		return "showInfo";
	}
	@GetMapping("/calculateSum/{a}/{b}")
	public String calculateSum(@PathVariable("a") int a , @PathVariable("b") int b, Model model) {
		
		int sum=a+b;
		model.addAttribute("sum", sum);
		return "calculateSum";
	}
	@GetMapping("/employeeForm")
	public String employeeForm() {
		return "employeeForm";
	}
	@GetMapping("/addNumbers")
	public String addNumber(@RequestParam("num1") int num1, @RequestParam("num2") int num2, Model model) {
		int sum=num1+num2;
		model.addAttribute("sum", sum);
		return "addNumbers";
	}
	@GetMapping("/combine")
	public String combine(@RequestParam("str1") String str1, @RequestParam("str2") String str2, Model model) {
		String ans=str1 +"  "+str2;
		model.addAttribute("ans", ans);
		return "combine";
	}
	@GetMapping("/calculate")
	public String calculate(@RequestParam("num1") int num1, @RequestParam("num2") int num2, Model model) {
		int sum=num1+num2;
		model.addAttribute("sum", sum);
		return "calculate";
	}
}
