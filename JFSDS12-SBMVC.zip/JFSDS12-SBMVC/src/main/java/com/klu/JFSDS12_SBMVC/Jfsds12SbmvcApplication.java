package com.klu.JFSDS12_SBMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jfsds12SbmvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jfsds12SbmvcApplication.class, args);
		System.out.println("Welcome to Spring boot MVC");
		
	}

}
